sthefany@sthefany:~/Documentos/5Periodo/EDII/T3/Q01$ ./teste
=== Torre de Hanoi com Grafo(Matriz)
Digite a configuracao inicial (pino de cada disco):
Disco: 0
Disco: 0
Disco: 0
Disco: 0

Estado inicial codificado: 0
Estado final codificado  : 80

Menor numero de movimentos: 15
Tempo gasto pelo Dijkstra: 0.000254 segundos.

Caminho (da configuracao inicial ate a configuracao final):
Passo 0: [ 0 0 0 0 ]
Passo 1: [ 1 0 0 0 ]
Passo 2: [ 1 2 0 0 ]
Passo 3: [ 2 2 0 0 ]
Passo 4: [ 2 2 1 0 ]
Passo 5: [ 0 2 1 0 ]
Passo 6: [ 0 1 1 0 ]
Passo 7: [ 1 1 1 0 ]
Passo 8: [ 1 1 1 2 ]
Passo 9: [ 2 1 1 2 ]
Passo 10: [ 2 0 1 2 ]
Passo 11: [ 0 0 1 2 ]
Passo 12: [ 0 0 2 2 ]
Passo 13: [ 1 0 2 2 ]
Passo 14: [ 1 2 2 2 ]
Passo 15: [ 2 2 2 2 ]

sthefany@sthefany:~/Documentos/5Periodo/EDII/T3/Q01$ ./teste
=== Torre de Hanoi com Grafo(Matriz)
Digite a configuracao inicial (pino de cada disco):
Disco: 1
Disco: 0
Disco: 0
Disco: 2

Estado inicial codificado: 55
Estado final codificado  : 80

Menor numero de movimentos: 7
Tempo gasto pelo Dijkstra: 0.000368 segundos.

Caminho (da configuracao inicial ate a configuracao final):
Passo 0: [ 1 0 0 2 ]
Passo 1: [ 2 0 0 2 ]
Passo 2: [ 2 1 0 2 ]
Passo 3: [ 1 1 0 2 ]
Passo 4: [ 1 1 2 2 ]
Passo 5: [ 0 1 2 2 ]
Passo 6: [ 0 2 2 2 ]
Passo 7: [ 2 2 2 2 ]

sthefany@sthefany:~/Documentos/5Periodo/EDII/T3/Q01$ ./teste
=== Torre de Hanoi com Grafo(Matriz)
Digite a configuracao inicial (pino de cada disco):
Disco: 2
Disco: 1
Disco: 0
Disco: 0

Estado inicial codificado: 5
Estado final codificado  : 80

Menor numero de movimentos: 15
Tempo gasto pelo Dijkstra: 0.000252 segundos.

Caminho (da configuracao inicial ate a configuracao final):
Passo 0: [ 2 1 0 0 ]
Passo 1: [ 0 1 0 0 ]
Passo 2: [ 0 2 0 0 ]
Passo 3: [ 2 2 0 0 ]
Passo 4: [ 2 2 1 0 ]
Passo 5: [ 0 2 1 0 ]
Passo 6: [ 0 1 1 0 ]
Passo 7: [ 1 1 1 0 ]
Passo 8: [ 1 1 1 2 ]
Passo 9: [ 2 1 1 2 ]
Passo 10: [ 2 0 1 2 ]
Passo 11: [ 0 0 1 2 ]
Passo 12: [ 0 0 2 2 ]
Passo 13: [ 1 0 2 2 ]
Passo 14: [ 1 2 2 2 ]
Passo 15: [ 2 2 2 2 ]




=== Torre de Hanoi com Grafo (Lista)===

Digite a configuracao inicial (pino de cada disco):
Disco: 0
Disco: 0
Disco: 0
Disco: 0

Estado inicial codificado: 0
Estado final codificado  : 80

Menor numero de movimentos (lista):  15
Tempo Dijkstra (lista) : 0.000211 segundos

Caminho (do estado inicial ate o estado final):
Passo 0: [ 0 0 0 0 ]
Passo 1: [ 1 0 0 0 ]
Passo 2: [ 1 2 0 0 ]
Passo 3: [ 2 2 0 0 ]
Passo 4: [ 2 2 1 0 ]
Passo 5: [ 0 2 1 0 ]
Passo 6: [ 0 1 1 0 ]
Passo 7: [ 1 1 1 0 ]
Passo 8: [ 1 1 1 2 ]
Passo 9: [ 2 1 1 2 ]
Passo 10: [ 2 0 1 2 ]
Passo 11: [ 0 0 1 2 ]
Passo 12: [ 0 0 2 2 ]
Passo 13: [ 1 0 2 2 ]
Passo 14: [ 1 2 2 2 ]
Passo 15: [ 2 2 2 2 ]

sthefany@sthefany:~/Documentos/5Periodo/EDII/T3/Q02$ ./teste
=== Torre de Hanoi com Grafo (Lista)===

Digite a configuracao inicial (pino de cada disco):
Disco: 1
Disco: 0
Disco: 0
Disco: 2

Estado inicial codificado: 55
Estado final codificado  : 80

Menor numero de movimentos (lista):  7
Tempo Dijkstra (lista) : 0.000198 segundos

Caminho (do estado inicial ate o estado final):
Passo 0: [ 1 0 0 2 ]
Passo 1: [ 2 0 0 2 ]
Passo 2: [ 2 1 0 2 ]
Passo 3: [ 1 1 0 2 ]
Passo 4: [ 1 1 2 2 ]
Passo 5: [ 0 1 2 2 ]
Passo 6: [ 0 2 2 2 ]
Passo 7: [ 2 2 2 2 ]

sthefany@sthefany:~/Documentos/5Periodo/EDII/T3/Q02$ ./teste
=== Torre de Hanoi com Grafo (Lista)===

Digite a configuracao inicial (pino de cada disco):
Disco: 2
Disco: 1
Disco: 0
Disco: 0

Estado inicial codificado: 5
Estado final codificado  : 80

Menor numero de movimentos (lista):  15
Tempo Dijkstra (lista) : 0.000255 segundos

Caminho (do estado inicial ate o estado final):
Passo 0: [ 2 1 0 0 ]
Passo 1: [ 0 1 0 0 ]
Passo 2: [ 0 2 0 0 ]
Passo 3: [ 2 2 0 0 ]
Passo 4: [ 2 2 1 0 ]
Passo 5: [ 0 2 1 0 ]
Passo 6: [ 0 1 1 0 ]
Passo 7: [ 1 1 1 0 ]
Passo 8: [ 1 1 1 2 ]
Passo 9: [ 2 1 1 2 ]
Passo 10: [ 2 0 1 2 ]
Passo 11: [ 0 0 1 2 ]
Passo 12: [ 0 0 2 2 ]
Passo 13: [ 1 0 2 2 ]
Passo 14: [ 1 2 2 2 ]
Passo 15: [ 2 2 2 2 ]


















A1 10
A2 20
A3 =A1
B1 5
B2 =A2
B3 @soma(A1..B2)
C1 7
C2 =B3
C3 @media(A1..C2)
D1 @max(A1..C3)
D2 @min(A1..C3)
E1 @soma(A1..D2)
F1 =E1
G1 200
H1 @soma(A1..H1)
SAIR


> BFS C3

[BFS] Visitando dependencias a partir de C3:
 - C3
 - C2
 - B2
 - A2
 - C1
 - B1
 - A1
 - B3



|   \ C  | A        | B        | C        | D        | E        | F        | G        | H        |

| 01   |    10.00 |     5.00 |     7.00 |    20.00 |    62.00 |     0.00 |   200.00 |   222.00 |
| 02   |    20.00 |    20.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 03   |    10.00 |    55.00 |    10.33 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 04   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 05   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 06   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 07   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 08   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 09   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 10   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 11   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 12   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 13   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 14   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 15   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 16   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 17   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 18   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 19   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 20   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
Digite 'SAIR' para encerrar.
> 

> DFS C3

[DFS] Visitando dependencias a partir de C3:
 - C3
 - C2
 - B3
 - B2
 - A2
 - B1
 - A1
 - C1



|   \ C  | A        | B        | C        | D        | E        | F        | G        | H        |

| 01   |    10.00 |     5.00 |     7.00 |    20.00 |    62.00 |     0.00 |   200.00 |   222.00 |
| 02   |    20.00 |    20.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 03   |    10.00 |    55.00 |    10.33 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 04   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 05   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 06   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 07   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 08   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 09   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 10   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 11   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 12   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 13   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 14   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 15   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 16   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 17   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 18   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 19   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 20   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
Digite 'SAIR'

> TEMPOS C3

[TEMPOS] Resultados (media de 30 repeticoes) a partir de C3:
  Insercao/Reconstrucao do grafo: 0.000013 s
  BFS: 0.000002 s
  DFS: 0.000001 s


|   \ C  | A        | B        | C        | D        | E        | F        | G        | H        |

| 01   |    10.00 |     5.00 |     7.00 |    20.00 |    62.00 |     0.00 |   200.00 |   222.00 |
| 02   |    20.00 |    20.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 03   |    10.00 |    55.00 |    10.33 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 04   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 05   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 06   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 07   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 08   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 09   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 10   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 11   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 12   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 13   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 14   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 15   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 16   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 17   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 18   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 19   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
| 20   |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |     0.00 |
Digite 'SAIR' para encerrar.
